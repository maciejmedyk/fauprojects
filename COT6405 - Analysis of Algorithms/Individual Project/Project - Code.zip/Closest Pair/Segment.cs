﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Closest_Pair
{
    class Segment
    {
        public Segment(Point p1, Point p2)
        {
            P1 = p1;
            P2 = p2;
        }

        public Point P1;
        public Point P2;

        public float Length()
        {
            return (float) Math.Sqrt(LengthSquared());
        }

        public double LengthSquared()
        {
            double result = ((P1.x - P2.x) * (P1.x - P2.x) + (P1.y - P2.y) * (P1.y - P2.y));
            return result;
        }
    }
}
