﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Closest_Pair
{
    class Timer
    {
        private DateTime timeStart;
        private DateTime timeEnd;
        private TimeSpan timeDiff;

        public Timer()
        {

        }

        public void start()
        {
            this.timeStart = DateTime.Now;
            //System.Console.WriteLine(timeStart.ToString("hh:mm:ss:ffff"));
        }

        public void end(System.IO.StreamWriter file)
        {
            this.timeEnd = DateTime.Now;
            //System.Console.WriteLine(timeEnd.ToString("hh:mm:ss:ffff"));
            timeDiff = timeEnd.Subtract(timeStart);
            System.Console.WriteLine("   Function run time : " + timeDiff);
            file.WriteLine("   Function run time : " + timeDiff);
            System.Console.WriteLine("   Milisecs run time : " + timeDiff.TotalMilliseconds.ToString());
            file.WriteLine("   Milisecs run time : " + timeDiff.TotalMilliseconds.ToString());
        }
    }
}
