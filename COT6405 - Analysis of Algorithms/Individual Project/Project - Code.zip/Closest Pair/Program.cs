﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace Closest_Pair
{
    class Program
    {
        static void Main(string[] args)
        {
            System.IO.StreamWriter file = new System.IO.StreamWriter("results.txt");
            Timer t = new Timer();
            int multiplier = 10000;
            int tries = 5;

            do
            {
                List<Point> points = new List<Point>();

                int seed = unchecked(DateTime.Now.Ticks.GetHashCode());
                Random random = new Random(seed);
                for (int i = 0; i < multiplier; i++)
                {
                    points.Add(new Point(random.Next(0, 10000000) + random.NextDouble(), random.Next(0, 10000000) + random.NextDouble()));
                }
                multiplier = multiplierChange(multiplier);

                System.Console.WriteLine("Calcualtions for " + points.Count.ToString() + " points");
                file.WriteLine("Calcualtions for " + points.Count.ToString() + " points");
                System.Console.WriteLine(" ");
                file.WriteLine(" ");

                for (int k = 1; k <= tries; k++)
                {
                    System.Console.WriteLine("Run # " + k.ToString());
                    file.WriteLine("Run # " + k.ToString());
                    System.Console.WriteLine("   Shortest distance with Brute Force");
                    file.WriteLine("   Shortest distance with Brute Force");
                    t.start();
                    BruteForce b = new BruteForce(points, file);
                    t.end(file);
                    System.Console.WriteLine(" ");
                    System.Console.WriteLine("   Shortest distance with Divide & Conquer");
                    file.WriteLine("   Shortest distance with Divide & Conquer");
                    t.start();
                    DivideAndConquer d = new DivideAndConquer(points, file);
                    t.end(file);
                }
                System.Console.WriteLine(" ");
                file.WriteLine(" ");

            } while (multiplier <= 100000);

            file.Close();

            Console.Write("Press any key to continue . . . ");
            Console.ReadKey(true);
        }

        public static int multiplierChange(int current)
        {
            int result = current;
            if (current == 10000) result = 15000;
            if (current == 15000) result = 20000;
            if (current == 20000) result = 25000;
            if (current == 25000) result = 30000;
            if (current == 30000) result = 35000;
            if (current == 35000) result = 40000;
            if (current == 40000) result = 45000;
            if (current == 45000) result = 50000;
            if (current == 50000) result = 55000;
            if (current == 55000) result = 60000;
            if (current == 60000) result = 65000;
            if (current == 65000) result = 70000;
            if (current == 70000) result = 75000;
            if (current == 75000) result = 80000;
            if (current == 80000) result = 85000;
            if (current == 85000) result = 90000;
            if (current == 90000) result = 95000;
            if (current == 95000) result = 100000;
            if (current == 100000) result = 105000;
            return result;
        }
    }
}
