﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Closest_Pair
{
    class BruteForce
    {

        public BruteForce(List<Point> points, System.IO.StreamWriter file)
        {
            Segment result = bruteForce(points);
            System.Console.WriteLine("   Point 1 : (" + result.P1.x.ToString() + ", " + result.P1.y.ToString() + ")");
            System.Console.WriteLine("   Point 2 : (" + result.P2.x.ToString() + ", " + result.P2.y.ToString() + ")");
            System.Console.WriteLine("   Shortest distance : " + result.Length().ToString());
            file.WriteLine("   Shortest distance : " + result.Length().ToString());
        }

        public Segment bruteForce(List<Point> points)
        {
            float shortestDistance = (float)Math.Sqrt(Math.Pow(points[0].y - points[1].y, 2.00) + Math.Pow(points[0].x - points[1].x, 2.00));
            Segment result = new Segment(points[0], points[1]);

            for (int i = 0; i < points.Count; i++)
            {
                for (int j = i + 1; j < points.Count; j++)
                {
                    if (Math.Sqrt(Math.Pow(points[j].y - points[i].y, 2.00) + Math.Pow(points[j].x - points[i].x, 2.00)) < shortestDistance)
                    {
                        shortestDistance = (float)Math.Sqrt(Math.Pow(points[j].y - points[i].y, 2.00) + Math.Pow(points[j].x - points[i].x, 2.00));
                        result = new Segment(points[i], points[j]);
                    }
                }
            }
            return result;
        }
    }
}
