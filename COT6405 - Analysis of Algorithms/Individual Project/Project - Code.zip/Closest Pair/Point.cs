﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Closest_Pair
{
    class Point
    {
        public double x { get; set; }
        public double y { get; set; }

        public Point(double xCoordinate, double yCoordinate)
        {
            x = xCoordinate;
            y = yCoordinate;
        }
    }
}
