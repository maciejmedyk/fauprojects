﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace CAP6776_HW03
{
    class CAP6776_HW03
    {
        static void Main(string[] args)
        {
            List<string> clusters = ReadFile("clustering_result.txt");
            List<string> labels = ReadFile("data_label.txt");
            Console.Out.WriteLine("Displaying Cluster vs Label Matrix \n");
            Display(Summation(FunctionT(clusters, labels)));
            float n = clusters.Count;

            float clustering_accuracy = Maximum(Summation(FunctionT(clusters, labels))) / n;
            Console.Out.WriteLine("Clustering Accuracy : " + clustering_accuracy + "\n");

            Console.Out.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        /**
         *  Extracts maximum counts from each cluster and returns maximum integer 
         **/
        public static int Maximum(Dictionary<int, Dictionary<int, int>> cluster_association)
        {

            string result = "";
            int maximum = 0;

            int size = cluster_association.Count;
            int maxvalue = 0;
            int[,] array = new int[size, size];
            for (int i = 1; i <= cluster_association.Count; i++)
            {
                for (int j = 1; j <= cluster_association.Count; j++)
                {
                    int tempInt;
                    Dictionary<int, int> tempDict;
                    cluster_association.TryGetValue(i, out tempDict);
                    tempDict.TryGetValue(j, out tempInt);
                    if (tempInt > maxvalue)
                    {
                        maxvalue = tempInt;
                    }
                }
            }

            for (int i = 1; i <= cluster_association.Count; i++)
            {
                for (int j = 1; j <= cluster_association.Count; j++)
                {
                    int tempInt;
                    Dictionary<int, int> tempDict;
                    cluster_association.TryGetValue(i, out tempDict);
                    tempDict.TryGetValue(j, out tempInt);
                    array[i - 1, j - 1] = maxvalue - tempInt;
                }
            }

            HungarianAlgorithm hungarian = new HungarianAlgorithm(array);
            int[] hungarianresults = hungarian.Evaluate();

            for (int i = 0; i < hungarianresults.Length; i++)
            {
                maximum += cluster_association[i + 1][hungarianresults[i] + 1];
                result += "(C" + (i + 1) + ",L" + (hungarianresults[i] + 1) + ") " + cluster_association[i + 1][hungarianresults[i] + 1] + " + ";
            }

            result = result.Substring(0, result.Length - 3) + " = " + maximum + "\n";
            Console.Out.WriteLine(result);
            return maximum;
        }

        /**
         *  Summarizes counts for all classes within clusters and returns dictionary of cluster counts
         **/
        public static Dictionary<int, Dictionary<int, int>> Summation(Dictionary<string, List<string>> cluster_association)
        {
            Dictionary<int, Dictionary<int, int>> result2D = new Dictionary<int, Dictionary<int, int>>();

            foreach (KeyValuePair<string, List<string>> entry in cluster_association)
            {
                int parsedKey = int.Parse(entry.Key);
                Dictionary<int, int> result1D = new Dictionary<int, int>();

                foreach (KeyValuePair<string, List<string>> subentry in cluster_association)
                {
                    int parsedKeyValue = int.Parse(subentry.Key);
                    result1D.Add(parsedKeyValue, 0);
                }

                for (int i = 0; i < entry.Value.Count; i++)
                {
                    int parsedKeyValue = int.Parse(entry.Value[i]);
                    result1D[parsedKeyValue] += 1;
                }
                result2D.Add(parsedKey, result1D);
            }
            return result2D;
        }

        /**
         *  Associates all clusters with classes and returns list of clusters
         **/
        public static Dictionary<string, List<string>> FunctionT(List<string> clusters, List<string> labels)
        {
            Dictionary<string, List<string>> cluster_association = new Dictionary<string, List<string>>();

            for (int i = 0; i < clusters.Count; i++)
            {    
                    if (cluster_association.ContainsKey(clusters[i]))
                    {
                        List<string> temp = cluster_association[clusters[i]];
                        temp.Add(labels[i]);
                        cluster_association[clusters[i]] = temp;
                    }
                    else
                    {
                        List<string> temp = new List<string>();
                        temp.Add(labels[i]);
                        cluster_association.Add(clusters[i], temp);
                    }
            }
            return cluster_association;
        }

        /**
         *  Reads files from the program and returns lists of strings
         **/
        public static List<string> ReadFile(String filename)
        {
            List<string> result = new List<string>();
            var lines = File.ReadLines(filename);
            foreach (var line in lines)
            {
                result.Add(line.Trim());
            }
            return result;
        }

        /**
         *  Displays the matrix of cluster class count allocation
         **/
        public static void Display(Dictionary<int, Dictionary<int, int>> cluster_association)
        {
            Console.Out.Write(SpaceOut("") + "  ");
            for (int i = 1; i <= cluster_association.Count; i++)
            {
                Console.Out.Write("L" + SpaceOut("(" + i + ")", 4, 0) + " ");
            }
            Console.Out.Write("\n");
            Console.Out.WriteLine(SpaceOut("") + " -------------------------------------------------------------");

            for(int i = 1; i <= cluster_association.Count; i++)
            {
                Console.Out.Write("C" + SpaceOut("(" + i  + ")"));
                Console.Out.Write("|");
                for(int j = 1; j <= cluster_association.Count; j++)
                {
                    int tempInt;
                    Dictionary<int, int> tempDict;
                    cluster_association.TryGetValue(i, out tempDict);
                    tempDict.TryGetValue(j, out tempInt);
                    Console.Out.Write(SpaceOut(tempInt.ToString()) + "|");
                }
                Console.Out.Write("\n");
                Console.Out.WriteLine(SpaceOut("") + " -------------------------------------------------------------");
            }
            Console.Out.Write("\n");
        }

        /**
         *  Spacing out for strings 
         */
        private static string SpaceOut(string input, int total = 5, int rmargin = 1)
        {
            string result = "";
            string margin = "";
            for (int i = 0; i < rmargin; i++) margin += " ";
            input = input + margin;
            int size = input.Length;
            for (int i = 0; i < total - size; i++) result += " ";
            return result + input;
        }
    }
}