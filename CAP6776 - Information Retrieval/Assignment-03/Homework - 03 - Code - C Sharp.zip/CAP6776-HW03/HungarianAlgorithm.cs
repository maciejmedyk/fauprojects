﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CAP6776_HW03
{
    class HungarianAlgorithm
    {
        private readonly int[,] matrix;
        private int maxvalue;
        private int numberofelements;
        private int[] clusters; //labels for workers
        private int[] labels; //labels for jobs 
        private bool[] clustervertices;
        private bool[] labelvertices;
        private int[] clusterscovered; //vertex matched with x
        private int[] labelscovered; //vertex matched with y
        private int totalcovered;
        private int[] yslack;
        private int[] xslack;
        private int[] paths; //memorizing paths

        public HungarianAlgorithm(int[,] matrixIn)
        {
            matrix = matrixIn;
        }

        public int[] Evaluate()
        {
            numberofelements = matrix.GetLength(0);

            clusters = new int[numberofelements];
            labels = new int[numberofelements];
            clustervertices = new bool[numberofelements];
            labelvertices = new bool[numberofelements];
            clusterscovered = new int[numberofelements];
            labelscovered = new int[numberofelements];
            yslack = new int[numberofelements];
            xslack = new int[numberofelements];
            paths = new int[numberofelements];
            maxvalue = int.MaxValue;


            InittiateMatches();

            if (numberofelements != matrix.GetLength(1))
                return null;

            IntitiateLabels();

            totalcovered = 0;

            InitialMatching();

            var queue = new Queue<int>();

            #region augment

            while (totalcovered != numberofelements)
            {
                queue.Clear();

                InitiateVertices();

                var root = 0;
                int xaxis;
                var yaxis = 0;

                for (xaxis = 0; xaxis < numberofelements; xaxis++)
                {
                    if (clusterscovered[xaxis] != -1) continue;
                    queue.Enqueue(xaxis);
                    root = xaxis;
                    paths[xaxis] = -2;

                    clustervertices[xaxis] = true;
                    break;
                }

                for (var i = 0; i < numberofelements; i++)
                {
                    yslack[i] = matrix[root, i] - clusters[root] - labels[i];
                    xslack[i] = root;
                }

                while (true)
                {
                    while (queue.Count != 0)
                    {
                        xaxis = queue.Dequeue();
                        var lxx = clusters[xaxis];
                        for (yaxis = 0; yaxis < numberofelements; yaxis++)
                        {
                            if (matrix[xaxis, yaxis] != lxx + labels[yaxis] || labelvertices[yaxis]) continue;
                            if (labelscovered[yaxis] == -1) break;
                            labelvertices[yaxis] = true;
                            queue.Enqueue(labelscovered[yaxis]);

                            AddToTree(labelscovered[yaxis], xaxis);
                        }
                        if (yaxis < numberofelements) break;
                    }
                    if (yaxis < numberofelements) break;
                    
                    UpdateLabels();

                    for (yaxis = 0; yaxis < numberofelements; yaxis++)
                    {
                        if (labelvertices[yaxis] || yslack[yaxis] != 0) continue;
                        if (labelscovered[yaxis] == -1)
                        {
                            xaxis = xslack[yaxis];
                            break;
                        }
                        labelvertices[yaxis] = true;
                        if (clustervertices[labelscovered[yaxis]]) continue;
                        queue.Enqueue(labelscovered[yaxis]);
                        AddToTree(labelscovered[yaxis], xslack[yaxis]);
                    }
                    if (yaxis < numberofelements) break;
                }

                totalcovered++;

                int totaly;
                for (int cx = xaxis, cy = yaxis; cx != -2; cx = paths[cx], cy = totaly)
                {
                    totaly = clusterscovered[cx];
                    labelscovered[cy] = cx;
                    clusterscovered[cx] = cy;
                }
            }

            #endregion

            return clusterscovered;
        }

        private void InittiateMatches()
        {
            for (var i = 0; i < numberofelements; i++)
            {
                clusterscovered[i] = -1;
                labelscovered[i] = -1;
            }
        }

        private void InitiateVertices()
        {
            for (var i = 0; i < numberofelements; i++)
            {
                clustervertices[i] = false;
                labelvertices[i] = false;
            }
        }

        private void IntitiateLabels()
        {
            for (var i = 0; i < numberofelements; i++)
            {
                var minRow = matrix[i, 0];
                for (var j = 0; j < numberofelements; j++)
                {
                    if (matrix[i, j] < minRow) minRow = matrix[i, j];
                    if (minRow == 0) break;
                }
                clusters[i] = minRow;
            }
            for (var j = 0; j < numberofelements; j++)
            {
                var minColumn = matrix[0, j] - clusters[0];
                for (var i = 0; i < numberofelements; i++)
                {
                    if (matrix[i, j] - clusters[i] < minColumn) minColumn = matrix[i, j] - clusters[i];
                    if (minColumn == 0) break;
                }
                labels[j] = minColumn;
            }
        }

        private void UpdateLabels()
        {
            var delta = maxvalue;
            for (var i = 0; i < numberofelements; i++)
                if (!labelvertices[i])
                    if (delta > yslack[i])
                        delta = yslack[i];
            for (var i = 0; i < numberofelements; i++)
            {
                if (clustervertices[i])
                    clusters[i] = clusters[i] + delta;
                if (labelvertices[i])
                    labels[i] = labels[i] - delta;
                else yslack[i] = yslack[i] - delta;
            }
        }

        private void AddToTree(int x, int prevx)
        {

            clustervertices[x] = true;
            paths[x] = prevx;

            var lxx = clusters[x];
            for (var y = 0; y < numberofelements; y++)
            {
                if (matrix[x, y] - lxx - labels[y] >= yslack[y]) continue;
                yslack[y] = matrix[x, y] - lxx - labels[y];
                xslack[y] = x;
            }
        }

        private void InitialMatching()
        {
            for (var x = 0; x < numberofelements; x++)
            {
                for (var y = 0; y < numberofelements; y++)
                {
                    if (matrix[x, y] != clusters[x] + labels[y] || labelscovered[y] != -1) continue;
                    clusterscovered[x] = y;
                    labelscovered[y] = x;
                    totalcovered++;
                    break;
                }
            }
        }
    }
}
