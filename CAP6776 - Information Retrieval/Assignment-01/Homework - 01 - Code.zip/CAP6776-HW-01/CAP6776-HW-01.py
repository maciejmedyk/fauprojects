__author__ = 'Maciej Medyk'
import nltk, string
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from collections import Counter

files = ["100554newsML.txt", "100593newsML.txt", "100618newsML.txt", "130040newsML.txt", "137871newsML.txt"]
documents = []

def tokenize(text):
    stop_words = set(stopwords.words("english"))
    exclude = set(string.punctuation)
    stemmer = PorterStemmer()
    text = ''.join(ch for ch in text if ch not in exclude)
    document = nltk.word_tokenize(text)
    document_filtered = []
    for word in document:
        if word not in stop_words:
            document_filtered.append(word.lower())
    return [stemmer.stem(item) for item in document_filtered]

def cosine_sim(text1, text2):
    vectorizer = TfidfVectorizer(tokenizer=tokenize, stop_words='english')
    tfidf = vectorizer.fit_transform([text1, text2])
    return ((tfidf * tfidf.T).A)[0, 1]

def readfile(path):
    with open(path, "r") as document:
        document = document.read().replace('\n', ' ')
    return document

def loadfile(files):
    for i in range(0, len(files)):
        documents.append(readfile("files\\" + str(files[i])))
        print (displayheader(str("file : " + files[i])) + "\n" + str(documents[i]) + "\n")
        print (str(tokenize(documents[i])) + "\n")
        print (str(Counter(tokenize(documents[i]))) + "\n")

def createtfidfmatrix():
    print displayheader("tf-idf for each word")
    vectors = TfidfVectorizer(tokenizer=tokenize, stop_words='english')
    tfs = vectors.fit_transform(documents)
    matrix = tfs.toarray()
    vocabulary = vectors.get_feature_names()
    print("%-20s%-20s%-20s%-20s%-20s%-20s" % (str(""), str(files[0]), str(files[1]), str(files[2]), str(files[3]), str(files[4])))
    print("--------------------------------------------------------------------------------------------------------------------")
    for i in range(0, len(vocabulary)):
        print ("%-20s%-20s%-20s%-20s%-20s%-20s" % (str(vocabulary[i]), str(matrix[0][i]), str(matrix[1][i]), str(matrix[2][i]), str(matrix[3][i]), str(matrix[4][i])))
    print ""

def comparedocuments(documents):
    print displayheader("cosine similarity for documents")
    vectors = TfidfVectorizer(tokenizer=tokenize, stop_words='english')
    tfidf = vectors.fit_transform([documents[0], documents[1], documents[2], documents[3], documents[4]])
    table = ((tfidf * tfidf.T).A)
    print("%-20s%-20s%-20s%-20s%-20s%-20s" % (str(""), str(files[0]), str(files[1]), str(files[2]), str(files[3]), str(files[4])))
    print("--------------------------------------------------------------------------------------------------------------------")
    for i in range(0, len(table)):
        print("%-20s%-20s%-20s%-20s%-20s%-20s" % (str(files[i]), str(table[0][i]), str(table[1][i]), str(table[2][i]), str(table[3][i]), str(table[4][i])))

def displayheader(header):
    result = "====================================================================================================================\n"
    result += header
    result += "\n===================================================================================================================="
    return result

loadfile(files)
createtfidfmatrix()
comparedocuments(documents)

