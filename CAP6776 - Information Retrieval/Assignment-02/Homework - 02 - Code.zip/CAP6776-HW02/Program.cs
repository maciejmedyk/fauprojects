﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace CAP6776_HW2
{
    class Program
    {
        private static List<List<string>> tokens = new List<List<string>>();
        private static List<string> sentences = new List<string>();

        static void Main(string[] args)
        {
            CreateFilesARFF("webkb-train-stemmed.txt", "Train");
            CreateFilesARFF("webkb-test-stemmed.txt", "Test");
        }

        public static void CreateFilesARFF(string filename, string filetype)
        {
            List<string> sentences = ReadFile(filename);
            sentences = ConvertFile(sentences, filetype);
            WriteFile(filename.Substring(0, filename.Length - 4) + ".arff", sentences);
        }

        public static List<string> ReadFile(string filename)
        {
            List<string> result = new List<string>();
            var lines = File.ReadLines(filename);
            foreach (var line in lines)
            {

                result.Add(line);
            }
            return result;
        }

        public static void WriteFile(string filename, List<string> sentences)
        {
            File.WriteAllLines(filename,sentences);
        }

        public static List<string> ConvertFile(List<string> sentences, string type)
        {
            List<string> result = new List<string>();
            result.Add("@relation 'WebKB " + type);
            result.Add("");
            result.Add("@attribute Text string");
            result.Add("@attribute class-att {student, faculty, project course}");
            result.Add("");
            result.Add("@data");
            result.Add("");
            foreach (var line in sentences)
            {
                int index = Search(line);
                string bodyClass = line.Substring(0, index);
                string bodyText = "'" + line.Substring(index + 1, line.Length - index - 1) + "'";
                result.Add(bodyText + "," + bodyClass);
            }
            return result;
        }

        public static int Search(string line)
        {
            for (int i = 0; i < line.Length; i++)
            {
                if (line[i] == '\t') return i;
                {

                }
            }
            return -1;
        }
    }
}
