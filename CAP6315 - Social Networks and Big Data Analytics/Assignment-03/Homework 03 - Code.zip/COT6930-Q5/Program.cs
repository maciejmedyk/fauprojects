﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COT6930_Q5
{
    class Program
    {
        static void Main(string[] args)
        {
            Matrix matrix = new Matrix();
            List<double> prob = new List<double>();
            prob.Add(0.05);
            prob.Add(0.20);
            prob.Add(0.40);
            List<List<float>> list = matrix.CreateMatrix("ClassMatrix.txt", 1);
            matrix.DisplayMatrix(list);
            System.IO.StreamWriter filelong = new System.IO.StreamWriter("resultlong.txt");
            System.IO.StreamWriter fileshort = new System.IO.StreamWriter("resultshort.txt");
            Console.WriteLine("\n-------------------------------------------------------------------");
            filelong.WriteLine("-------------------------------------------------------------------");
            fileshort.WriteLine("-------------------------------------------------------------------");
            for (int i = 0; i < prob.Count; i++)
            {
                Console.WriteLine("Probability   : " + prob[i].ToString());
                filelong.WriteLine("Probability   : " + prob[i].ToString());
                fileshort.WriteLine("Probability   : " + prob[i].ToString());
                Console.WriteLine("-------------------------------------------------------------------");
                filelong.WriteLine("-------------------------------------------------------------------");
                fileshort.WriteLine("-------------------------------------------------------------------");
                list = matrix.CreateMatrix("ClassMatrix.txt", prob[i]);
                for (int j = 0; j < list.Count; j++)
                {
                    for (int k = 0; k < 10; k++) matrix.CascadeInfluence(list, j, k, filelong, fileshort);
                }
            }
            filelong.Close();
            fileshort.Close();
            Console.Write("\nPress any key to continue . . . ");
            Console.ReadKey(true);
        }

        public class Matrix
        {
            public List<List<float>> CreateMatrix(string filename, double probability)
            {
                var lines = File.ReadLines(filename);
                int seed = unchecked(DateTime.Now.Ticks.GetHashCode());

                Random random = new Random(seed);
                List<List<float>> result = new List<List<float>>();

                foreach (var line in lines)
                {
                    List<float> list = new List<float>();
                    for (int i = 0; i < line.Length; i++)
                    {
                        if (line[i] == '1') list.Add(1);
                        else if (line[i] == ' ') continue;
                        else list.Add((float)(Math.Round(0.00, 1)));
                    }
                    result.Add(list);
                }

                for (int i = 0; i < result.Count; i++)
                {
                    for (int j = i; j < result.Count; j++)
                    {
                        if (result[i][j] == 1)
                        {
                            float number = ((float) probability);
                            result[i][j] = number;
                            result[j][i] = number;
                        }
                    }
                }
                return result;
            }
            public void CascadeInfluence(List<List<float>> matrix, int startnode, int runtime, System.IO.StreamWriter filelong, System.IO.StreamWriter fileshort)
            {
                List<float> neighbors = CreateList(matrix.Count);
                List<float> oldactive = CreateList(matrix.Count);
                List<float> newactive = CreateList(matrix.Count);
                newactive[startnode] = 1;
                Console.WriteLine("Iteration Run : " + (runtime + 1).ToString() +  " => Initiation");
                filelong.WriteLine("Iteration Run : " + (runtime + 1).ToString() + " => Initiation");
                fileshort.WriteLine("Iteration Run : " + (runtime + 1).ToString() + " => Initiation");
                Console.WriteLine("Starting Node : " + (startnode + 1).ToString());
                filelong.WriteLine("Starting Node : " + (startnode + 1).ToString());
                fileshort.WriteLine("Starting Node : " + (startnode + 1).ToString());
                Console.WriteLine("-------------------------------------------------------------------");
                filelong.WriteLine("-------------------------------------------------------------------");
                fileshort.WriteLine("-------------------------------------------------------------------");
                do
                {
                    Console.WriteLine("\nOld Active Nodes   : " + DisplayNodes(oldactive));
                    filelong.WriteLine("\nOld Active Nodes   : " + DisplayNodes(oldactive));
                    Console.WriteLine("New Active Nodes   : " + DisplayNodes(newactive));
                    filelong.WriteLine("New Active Nodes   : " + DisplayNodes(newactive));
                    neighbors = AddNeighbors(matrix, newactive, oldactive);
                    Console.WriteLine("Inactive Neighbors : " + DisplayNodes(neighbors) + "\n");
                    filelong.WriteLine("Inactive Neighbors : " + DisplayNodes(neighbors) + "\n");
                    List<List<float>> result = Cascade(neighbors, newactive, oldactive, matrix, filelong);
                    oldactive = result[0];
                    newactive = result[1];
                } while (DisplayNodes(neighbors) != "None");

                int count = 0;
                for (int i = 0; i < oldactive.Count; i++) if (oldactive[i] > 0) count++;
                Console.WriteLine("Count : " + count.ToString());
                filelong.WriteLine("Count : " + count.ToString());
                fileshort.WriteLine("Count : " + count.ToString());
                Console.WriteLine("-------------------------------------------------------------------");
                filelong.WriteLine("-------------------------------------------------------------------");
                fileshort.WriteLine("-------------------------------------------------------------------");
                Console.WriteLine("Iteration Run : " + (runtime + 1).ToString() + " => Complete");
                filelong.WriteLine("Iteration Run : " + (runtime + 1).ToString() + " => Complete");
                Console.WriteLine("-------------------------------------------------------------------\n");
                filelong.WriteLine("-------------------------------------------------------------------\n");
                Console.WriteLine("-------------------------------------------------------------------");
                filelong.WriteLine("-------------------------------------------------------------------");
             }
            public List<float> CreateList(int count)
            {
                List<float> result = new List<float>();
                for (int i = 0; i < count; i++) result.Add(0);
                return result;
            }
            private List<float> AddNeighbors(List<List<float>> matrix, List<float> newactive, List<float> oldactive)
            {
                List<float> neighbors = CreateList(matrix.Count);
                for (int j = 0; j < matrix.Count; j++)
                {
                    if (newactive[j] > 0)
                    {
                        for (int k = 0; k < matrix.Count; k++)
                        {
                            if (neighbors[k] == 0) neighbors[k] = matrix[j][k];
                            if (newactive[k] > 0) neighbors[k] = 0;
                            if (oldactive[k] > 0) neighbors[k] = 0;
                        }
                    }
                }
                return neighbors;
            }
            private List<float> GetNeighbors(List<List<float>> matrix, int index)
            {
                List<float> neighbors = CreateList(matrix.Count);
                for (int j = 0; j < matrix.Count; j++)
                {
                    neighbors[j] = matrix[index][j];
                }
                return neighbors;
            }
            public void DisplayMatrix(List<List<float>> matrix)
            {
                for(int i = 0; i < matrix.Count; i++)
                {
                    for(int j = 0; j < matrix.Count; j++)
                    {
                        if(matrix[i][j] > 0) Console.Write("1 ");
                        else Console.Write("0 ");
                    }
                    Console.Write("\n");
                }
            }
            private string DisplayNodes(List<float> list)
            {
                string result = "";
                for (int i = 0; i < list.Count; i++) if (list[i] > 0) result += (i + 1).ToString() + ", ";
                if (result.Length < 3) return "None";
                return result.Substring(0, result.Length - 2);
            }
            private List<List<float>> Cascade(List<float> neighbors, List<float> newact, List<float> oldact, List<List<float>> matrix, System.IO.StreamWriter filelong)
            {
                List<List<float>> result = new List<List<float>>();
                List<float> tempactive = CreateList(matrix.Count);
                int seed = unchecked(DateTime.Now.Ticks.GetHashCode());
                Random random = new Random(seed);
                for (int k = 0; k < matrix.Count; k++) if (newact[k] > 0) oldact[k] = newact[k];

                for (int k = 0; k < matrix.Count; k++)
                {
                    if (newact[k] > 0)
                    {
                        neighbors = GetNeighbors(matrix, k);
                        for (int i = 0; i < matrix.Count; i++)
                        {
                            if (neighbors[i] > 0 && oldact[i] == 0)
                            {
                                float roll = (float)Math.Round(random.NextDouble(), 2);
                                if (roll <= matrix[k][i])
                                {
                                    Console.WriteLine("Node " + SpaceOut((k + 1), (newact.Count.ToString()).Length) + " -> " + SpaceOut((i + 1), (newact.Count.ToString()).Length) + " => " + DisplayNeighborValue(matrix[k][i]) + " => Successful ");
                                    filelong.WriteLine("Node " + SpaceOut((k + 1), (newact.Count.ToString()).Length) + " -> " + SpaceOut((i + 1), (newact.Count.ToString()).Length) + " => " + DisplayNeighborValue(matrix[k][i]) + " => Successful ");
                                    tempactive[i] = 1;
                                }
                                else
                                {
                                    Console.WriteLine("Node " + SpaceOut((k + 1), (newact.Count.ToString()).Length) + " -> " + SpaceOut((i + 1), (newact.Count.ToString()).Length) + " => " + DisplayNeighborValue(matrix[k][i]) + " => Unsuccessful ");
                                    filelong.WriteLine("Node " + SpaceOut((k + 1), (newact.Count.ToString()).Length) + " -> " + SpaceOut((i + 1), (newact.Count.ToString()).Length) + " => " + DisplayNeighborValue(matrix[k][i]) + " => Unsuccessful ");
                                }
                            }
                        }
                    }
                }
                newact = tempactive;
                result.Add(oldact);
                result.Add(newact);
                return result;
            }
            private string SpaceOut(int number, int numbermax)
            {
                string result = "";
                for (int i = 0; i < (numbermax - ((number).ToString()).Length); i++) { result += "0"; }
                string n = number.ToString();
                result = result + n;
                return result;
            }

            private string DisplayNeighborValue(double value)
            {
                if (value == 0) return "0.0";
                else if (value == 1) return "1.0";
                else return (string)Math.Round(value, 2).ToString();
            }
        }
    }
}
