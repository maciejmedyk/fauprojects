﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COT6427_HW02
{
    public partial class MainForm : Form
    {
        int primeNumber;
        int amountOfPlayers;
        int threshold = 3;
        bool additionOperation = true;
        List<int> privateKeys = new List<int>();
        List<int> gateCalculations = new List<int>();
        List<List<int>> functionParams = new List<List<int>>();
        List<List<int>> playersPublicKeys = new List<List<int>>();

        public MainForm()
        {
            InitializeComponent();
            amountOfPlayersBox.Items.Add(3);
            amountOfPlayersBox.Items.Add(4);
            amountOfPlayersBox.Items.Add(5);
            amountOfPlayersBox.Items.Add(6);
            amountOfPlayersBox.Items.Add(7);
            amountOfPlayersBox.SelectedIndex = 0;
            primeNumber = Prime.GeneratePrime();
            label2.Text = "Auto-Generated Prime : " + primeNumber.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            amountOfPlayers = int.Parse(amountOfPlayersBox.Text);
            amountOfPlayersBox.Enabled = false;
            button1.Enabled = false;
            panel1.Visible = true;

            for (int i = 0; i < amountOfPlayers; i++)
            {
                List<int> param = new List<int>();
                param.Add(0);

                for(int j = 1; j < threshold; j++)
                {
                    Thread.Sleep(1);
                    param.Add(new Random((int)DateTime.Now.Ticks).Next(1, 10));
                }
                functionParams.Add(param);
            }

            textBox1.Focus();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string inputText = textBox1.Text;
            int currentSize = privateKeys.Count;
            int currentPlayers = functionParams.Count;
            string textToDisplay = "";

            if (inputText.Length != 0)
            {
                try
                {
                    if (int.Parse(inputText) > primeNumber)
                    {
                        textToDisplay += "Error : " + inputText + " is bigger than " + primeNumber + " !";
                    }
                    else
                    {
                        textToDisplay += "Function f(x) = " + inputText + " + " + functionParams[currentSize][1] + "x + " + functionParams[currentSize][2] + "x\xB2\n\n";
                        for (int i = 0; i < currentPlayers; i++)
                        {
                            int calculation = (int)((int.Parse(inputText) + (functionParams[currentSize][1] * (i + 1)) + (functionParams[currentSize][2] * Math.Pow((i + 1), 2))) % primeNumber);
                            textToDisplay += "Public Key Issued By Player " + (i + 1) + " : f ( " + (i + 1) + " ) = " + calculation + "\n";
                        }
                    }
                }
                catch
                {
                    textToDisplay += "Error : " + inputText + " is not a number !";
                }
            }

            playerBox.Text = textToDisplay;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string inputText = textBox1.Text;
            string textToDisplay = "";
            if (inputText.Length > 0)
            {
                int currentSize = privateKeys.Count;
                int currentPlayers = functionParams.Count;

                if (currentSize < amountOfPlayers)
                {
                    label3.Text = "Enter Private Key For Player " + (currentSize + 2);
                    functionParams[currentSize][0] = (int.Parse(textBox1.Text));
                    privateKeys.Add(int.Parse(textBox1.Text));
                    List<int> param = new List<int>();
                    for (int i = 0; i < currentPlayers; i++)
                    {
                         param.Add((int)((int.Parse(inputText) + (functionParams[currentSize][1] * (i + 1)) + (functionParams[currentSize][2] * Math.Pow((i + 1), 2))) % primeNumber));
                    }
                    playersPublicKeys.Add(param);
                }

                if (currentSize == amountOfPlayers - 1) 
                {
                    panel1.Visible = false;
                    panel2.Visible = true;
                    for (int i = 0; i < currentPlayers; i++)
                    {
                        textToDisplay += "Public Keys Received By Player " + (i + 1) + " : f ( " + (i + 1) + " ) = ";
                        for (int j = 0; j < playersPublicKeys[i].Count; j++) 
                        {
                            textToDisplay += "[ " + playersPublicKeys[j][i] + " ] ";
                        }
                        textToDisplay += "\n";
                    }
                    summaryBox.Text = textToDisplay;
                }
                textBox1.Text = "";
            }
            textBox1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string inputText = textBox1.Text;
            int currentSize = privateKeys.Count;
            int currentPlayers = functionParams.Count;
            string textToDisplay = "\nYou have chosen addition operation\n\n";

            for (int i = 0; i < currentPlayers; i++)
            {
                int summation = 0;
                for (int j = 0; j < playersPublicKeys[i].Count; j++)
                {
                    summation += playersPublicKeys[j][i];
                    textToDisplay += "[ " + playersPublicKeys[j][i] + " ] + ";
                }
                textToDisplay = textToDisplay.Substring(0, textToDisplay.Length - 3);
                textToDisplay += " mod ( " + primeNumber + " ) = " + (summation % primeNumber) + "\n";
                gateCalculations.Add(summation % primeNumber);
            }

            summaryBox.Text += textToDisplay;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Visible = true;
            button5.ForeColor = System.Drawing.Color.Tomato;
            additionOperation = true;
        }


        private void button4_Click(object sender, EventArgs e)
        {
            string inputText = textBox1.Text;
            int currentSize = privateKeys.Count;
            int currentPlayers = functionParams.Count;
            string textToDisplay = "\nYou have chosen multiplication operation\n\n";
            List<double> vdm = VDM.GenerateVDM(amountOfPlayers);
            double multiplication1 = 1.0;

            button3.Enabled = false;
            button4.Enabled = false;
            button5.Visible = true;
            button5.ForeColor = System.Drawing.Color.Tomato;
            additionOperation = false;
            textToDisplay += "Resharing public keys using g(x) function to reduce degree\n";
            

            for (int i = 0; i < currentPlayers; i++)
            {
                double multiplication3 = 0;
                for (int j = 0; j < playersPublicKeys[i].Count; j++)
                {
                    multiplication3 += playersPublicKeys[i][j] * vdm[j];
                }
                multiplication1 *= multiplication3;
            }

            for (int i = 0; i < amountOfPlayers; i++)
            {
                textToDisplay += "\nPublic Keys Received By Player " + (i + 1) + " : g ( " + (i + 1) + " ) = ";
                for (int j = 0; j < amountOfPlayers; j++)
                {
                    int calculation = (int)((multiplication1 + (2 * (j + 2) * (i + 1)) + (2 * (j + 2) * Math.Pow((i + 1), 2))) % primeNumber);
                    calculation = calculation % primeNumber;
                    if (calculation < 0)
                    {
                        calculation += primeNumber;
                    }
                    playersPublicKeys[j][i] = calculation;
                    textToDisplay += "[ " + calculation + " ]";
                }
            }

            textToDisplay += "\n\n";
            for (int i = 0; i < currentPlayers; i++)
            {
                double addition = 0;
                for (int j = 0; j < currentPlayers; j++)
                {
                    addition += vdm[j] * playersPublicKeys[j][i];
                    textToDisplay += "[ " + playersPublicKeys[j][i] + " * " + vdm[j] + " ] + ";
                }
                addition = addition % primeNumber;
                if (addition < 0)
                {
                    addition += primeNumber; 
                }
                textToDisplay = textToDisplay.Substring(0, textToDisplay.Length - 3);
                textToDisplay += " mod ( " + primeNumber + " ) = " + (addition % primeNumber) + "\n";
                gateCalculations.Add((int) addition);
            }

            summaryBox.Text += textToDisplay;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            recovery();
            button5.Enabled = false;
        }

        private void recovery()
        {
            double recovery = 0.0;
            string textToDisplay = "\n";
            for (int i = 0; i < amountOfPlayers; i++) 
            {
                double publicKey = gateCalculations[i];
                for (double j = 0; j < amountOfPlayers; j++) 
                {
                    if (i != j)
                    {
                        double nominator = (j + 1);
                        double denominator = ((j + 1) - (i + 1));
                        double nomDenom = nominator / denominator;
                        publicKey *= nomDenom;
                    }
                }
                recovery += publicKey;
            }
            recovery = recovery % primeNumber;

            while (recovery < 0)
            {
                recovery += primeNumber;
            }

            if (additionOperation)
            {
                textToDisplay += "MPC result for addition operation of all private keys = " + (Math.Round(recovery)).ToString();
            }
            else
            {
                textToDisplay += "MPC result for multiplication operation of all private keys =  " + (Math.Round(recovery)).ToString();
            }

            summaryBox.Text += textToDisplay;
        }
    }

    static class Prime
    {
        public static int GeneratePrime()
        {
            bool isPrime = false;
            int prime = 0;

            do
            {
                prime = new Random((int)DateTime.Now.Ticks).Next(50, 2000);
                isPrime = primeCheck(prime);
            } while (isPrime == false);

            return prime;
        }

        private static bool primeCheck(int prime)
        {
            if (prime <= 1) return false;
            else if (prime <= 3) return true;
            else if (prime % 2 == 0 || prime % 3 == 0) return false;
            long i = 5;
            while (i * i <= prime)
            {
                if (prime % i == 0 || prime % (i + 2) == 0) return false;
                i = i + 6;
            }
            return true;
        }
    }

    static class VDM
    {
        public static List<double> GenerateVDM(int amountOfPlayers)
        {
            List<double> playersThree = new List<double>();
            List<double> playersFour = new List<double>();
            List<double> playersFive = new List<double>();
            List<double> playersSix = new List<double>();
            List<double> playersSeven = new List<double>();

            playersThree.Add(3.0);
            playersThree.Add(-3.0);
            playersThree.Add(1.0);

            playersFour.Add(4.0);
            playersFour.Add(-6.0);
            playersFour.Add(4.0);
            playersFour.Add(-1.0);

            playersFive.Add(5.0);
            playersFive.Add(-10.0);
            playersFive.Add(10.0);
            playersFive.Add(-5.0);
            playersFive.Add(1.0);

            playersSix.Add(6.0);
            playersSix.Add(-15.0);
            playersSix.Add(20.0);
            playersSix.Add(-15.0);
            playersSix.Add(6.0);
            playersSix.Add(-1.0);

            playersSeven.Add(7.0);
            playersSeven.Add(-21.0);
            playersSeven.Add(35.0);
            playersSeven.Add(-35.0);
            playersSeven.Add(21.0);
            playersSeven.Add(-7.0);
            playersSeven.Add(1.0);

            if (amountOfPlayers == 3) return playersThree;
            else 
            if (amountOfPlayers == 4) return playersFour;
            else 
            if (amountOfPlayers == 5) return playersFive;
            else 
            if (amountOfPlayers == 6) return playersSix;
            else 
            return playersSeven;
        }
    }
}
