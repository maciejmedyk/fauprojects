﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using Deveel.Math;

namespace COT6427
{
    public partial class MainForm : Form
    {
        private readonly string FPSB = "First Price Sealed Bid Auction";
        private readonly string SPSB = "Second Price Sealed Bid Auction";
        Dictionary<String, List<BigInteger>> bids;
        Random randomizer = new Random();
        Random random;
        List<int> servers;
        int timeLeft = 30;
        int threshold = 2;
        BigInteger modulus;
        BigInteger maximumBid = 999999999999;

        public MainForm()
        {
            InitializeComponent();
            random = new Random();
            bids = new Dictionary<string, List<BigInteger>>();
            servers = new List<int>();
            servers.Add(1);
            servers.Add(1);
            servers.Add(1);
            servers.Add(1);
            atcombo.Items.Add(FPSB);
            atcombo.Items.Add(SPSB);
            atcombo.SelectedIndex = 0;
            timelabel.Text = "Seconds Remaining : " + timeLeft;
            modulus = BigInteger.ProbablePrime(128, random);
            modulolabel.Text = " Modulus : " + modulus;
            atcombo.ForeColor = Color.Navy;
            Font font = atcombo.Font;
            atcombo.Font = new Font(font, FontStyle.Bold);
            timer.Start();                   
        }

        private void p1button_Click(object sender, EventArgs e)
        {
            p1text.Visible = false;
            p1button.Visible = false;
            try
            {
                BigInteger p1bid = BigInteger.Parse(p1text.Text);
                if (p1bid > maximumBid) throw new Exception();
                createShares("Player 1", p1bid);
                checkAuctionType();
            }
            catch (Exception)
            {
                p1text.BackColor = Color.Yellow;
                p1text.Visible = true;
                p1button.Visible = true;
                p1text.Focus();
            }
        }

        private void p2button_Click(object sender, EventArgs e)
        {
            p2text.Visible = false;
            p2button.Visible = false;
            try
            {
                BigInteger p2bid = BigInteger.Parse(p2text.Text);
                if (p2bid > maximumBid) throw new Exception();
                createShares("Player 2", p2bid);
                checkAuctionType();
            }
            catch (Exception)
            {
                p2text.BackColor = Color.Yellow;
                p2text.Visible = true;
                p2button.Visible = true;
                p2text.Focus();
            }
        }

        private void p3button_Click(object sender, EventArgs e)
        {
            p3text.Visible = false;
            p3button.Visible = false;
            try
            {
                BigInteger p3bid = BigInteger.Parse(p3text.Text);
                if (p3bid > maximumBid) throw new Exception();
                createShares("Player 3", p3bid);
                checkAuctionType();
            }
            catch (Exception)
            {
                p3text.BackColor = Color.Yellow;
                p3text.Visible = true;
                p3button.Visible = true;
                p3text.Focus();
            }
        }

        private void p4button_Click(object sender, EventArgs e)
        {
            p4text.Visible = false;
            p4button.Visible = false;
            try
            {
                BigInteger p4bid = BigInteger.Parse(p4text.Text);
                if (p4bid > maximumBid) throw new Exception();
                createShares("Player 4", p4bid);
                checkAuctionType();
            }
            catch (Exception)
            {
                p4text.BackColor = Color.Yellow;
                p4text.Visible = true;
                p4button.Visible = true;
                p4text.Focus();
            }
        }

        private void p5button_Click(object sender, EventArgs e)
        {
            p5text.Visible = false;
            p5button.Visible = false;
            try
            {
                BigInteger p5bid = BigInteger.Parse(p5text.Text);
                if (p5bid > maximumBid) throw new Exception();
                createShares("Player 5", p5bid);
                checkAuctionType();
            }
            catch (Exception)
            {
                p5text.BackColor = Color.Yellow;
                p5text.Visible = true;
                p5button.Visible = true;
                p5text.Focus();
            }
        }

        private void p6button_Click(object sender, EventArgs e)
        {
            p6text.Visible = false;
            p6button.Visible = false;
            try
            {
                BigInteger p6bid = BigInteger.Parse(p6text.Text);
                if (p6bid > maximumBid) throw new Exception();
                createShares("Player 6", p6bid);
                checkAuctionType();
            }
            catch (Exception)
            {
                p6text.BackColor = Color.Yellow;
                p6text.Visible = true;
                p6button.Visible = true;
                p6text.Focus();
            }
        }

        private void p7button_Click(object sender, EventArgs e)
        {
            p7text.Visible = false;
            p7button.Visible = false;
            try
            {
                BigInteger p7bid = BigInteger.Parse(p7text.Text);
                if (p7bid > maximumBid) throw new Exception();
                createShares("Player 7", p7bid);
                checkAuctionType();
            }
            catch (Exception)
            {
                p7text.BackColor = Color.Yellow;
                p7text.Visible = true;
                p7button.Visible = true;
                p7text.Focus();
            }
        }

        private void p8button_Click(object sender, EventArgs e)
        {
            p8text.Visible = false;
            p8button.Visible = false;
            try
            {
                BigInteger p8bid = BigInteger.Parse(p8text.Text);
                if (p8bid > maximumBid) throw new Exception();
                createShares("Player 8", p8bid);
                checkAuctionType();
            }
            catch (Exception)
            {
                p8text.BackColor = Color.Yellow;
                p8text.Visible = true;
                p8button.Visible = true;
                p8text.Focus();
            }
        }

        private void s1button_Click(object sender, EventArgs e)
        {
            s1button.Text = "OFFLINE";
            s1button.ForeColor = Color.Red;
            s1text.Visible = false;
            servers[0] = 0;
            thresholdCheck();
            checkAuctionType();
        }

        private void s2button_Click(object sender, EventArgs e)
        {
            s2button.Text = "OFFLINE";
            s2button.ForeColor = Color.Red;
            s2text.Visible = false;
            servers[1] = 0;
            thresholdCheck();
            checkAuctionType();
        }

        private void s3button_Click(object sender, EventArgs e)
        {
            s3button.Text = "OFFLINE";
            s3button.ForeColor = Color.Red;
            s3text.Visible = false;
            servers[2] = 0;
            thresholdCheck();
            checkAuctionType();
        }

        private void s4button_Click(object sender, EventArgs e)
        {
            s4button.Text = "OFFLINE";
            s4button.ForeColor = Color.Red;
            s4text.Visible = false;
            servers[3] = 0;
            thresholdCheck();
            checkAuctionType();
        }

        private void checkAuctionType()
        {
            if (atcombo.Text.Equals(FPSB)) atcombo.Text = FPSB;
            else if (atcombo.Text.Equals(SPSB)) atcombo.Text = SPSB;
            else atcombo.Text = FPSB;
            atcombo.Enabled = false;
        }

        private void thresholdCheck()
        {
            int thresholdCheck = 0;
            foreach(int server in servers) 
            {
                thresholdCheck += server;
            }
            if (thresholdCheck <= threshold)
            {
                auctionShutdown();
                timer.Stop();
                timelabel.Text = "Seconds Remaining : 0";
                timelabel.BackColor = Color.Red;
                finalizetext.Text += "Message Sent [ Auction Cancelled : Not enough servers online to conduct auction ]";

            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (timeLeft > 0)
            {
                timelabel.Text = "Seconds Remaining : " + timeLeft;
                timeLeft = timeLeft - 1;
                if (timeLeft < 10) timelabel.BackColor = Color.Yellow;
                if (timeLeft < 05) timelabel.BackColor = Color.Red; 
            }
            else
            {
                timelabel.Text = "Seconds Remaining : 0";
                timer.Stop();
                auctionShutdown();
                determineWinner();
            }
        }

        private void createShares(string player, BigInteger bid)
        {
            List<BigInteger> list = new List<BigInteger>();
            BigInteger x1 = random.Next(888811000, 888812000);
            BigInteger x2 = random.Next(888812000, 888813000);
            for (int i = 0; i < servers.Count; i++)
            {
                BigInteger share = bid + (x1.Pow(1) * (i + 1)) + (x2.Pow(1) * (i + 1)) + (x1.Pow(2) * (i + 1)) + (x2.Pow(2) * (i + 1));
                share = share % modulus;
                list.Add(share);
            }
            bids.Add(player, list);
            displayShares();
        }

        private void displayShares()
        {
            s1text.Text = "";
            s2text.Text = "";
            s3text.Text = "";
            s4text.Text = "";
            foreach (string share in bids.Keys) 
            {
                s1text.Text += share + " : [( " + 1 + " ),( " + bids[share][0] + " )]";
                s1text.AppendText(Environment.NewLine);
                s2text.Text += share + " : [( " + 2 + " ),( " + bids[share][1] + " )]";
                s2text.AppendText(Environment.NewLine);
                s3text.Text += share + " : [( " + 3 + " ),( " + bids[share][2] + " )]";
                s3text.AppendText(Environment.NewLine);
                s4text.Text += share + " : [( " + 4 + " ),( " + bids[share][3] + " )]";
                s4text.AppendText(Environment.NewLine);
            }
        }

        private void determineWinner() 
        {
            SortedList<BigInteger, string> determination = new SortedList<BigInteger, string>();
            checkAuctionType();

            foreach (string key in bids.Keys) 
            {
                finalizetext.Text += "[ " + key + " ] :";
                for(int i = 0; i < bids[key].Count; i++)
                {
                    if(servers[i] == 1) finalizetext.Text += " [( " + (i + 1) + " ),( " + bids[key][i] + " )] ";
                }
                BigInteger recoverdBid = recovery(bids[key]);
                determination.Add(recoverdBid, key);
                finalizetext.Text += "= " + recoverdBid;
                finalizetext.AppendText(Environment.NewLine);
            }
            if (bids.Count > 0)
            {
                finalizetext.AppendText(Environment.NewLine);
                string winningPerson = determination.Last().Value;
                BigInteger winningFirstPriceBid = determination.Last().Key;
                determination.Remove(winningFirstPriceBid);
                BigInteger winningSecondPriceBid;
                if (bids.Count > 1) winningSecondPriceBid = determination.Last().Key;
                else winningSecondPriceBid = winningFirstPriceBid;
                if (atcombo.Text.Equals(SPSB)) finalizetext.Text += "Message Sent [ Auction : SPSB || Winner : " + winningPerson + "  ||  Bid Amount : $" + winningFirstPriceBid + "  ||  Pay Amount : $" + winningSecondPriceBid + " ]";
                else finalizetext.Text += "Message Sent [ Auction : FPSB || Winner : " + winningPerson + "  ||  Bid Amount : $" + winningFirstPriceBid + "  ||  Pay Amount : $" + winningFirstPriceBid + " ]";
                finalizetext.AppendText(Environment.NewLine);
                finalizetext.Text += "Message Sent [ Verification Shares :";
                for (int i = 0; i < bids[winningPerson].Count; i++)
                {
                    if (servers[i] == 1) finalizetext.Text += " [( " + (i + 1) + " ),( " + bids[winningPerson][i] + " )] ";
                }
                finalizetext.Text += "]";
                showWinner(winningPerson);
            }
            else
            {
                if (atcombo.Text.Equals(SPSB))
                {
                    finalizetext.Text += "Message Sent [ Auction : SPSB || Winner : none  ||  Bid Amount : none  ||  Pay Amount : none ]";
                    finalizetext.AppendText(Environment.NewLine);
                    finalizetext.Text += "Message Sent [ Verification Shares : no bid shares submitted ]";
                }
                else
                {
                    finalizetext.Text += "Message Sent [ Auction : FPSB || Winner : none  ||  Bid Amount : none  ||  Pay Amount : none ]";
                    finalizetext.AppendText(Environment.NewLine);
                    finalizetext.Text += "Message Sent [ Verification Shares : no bid shares submitted ]";
                }
            }  
        }

        private BigInteger recovery(List<BigInteger> bid)
        {
            BigDecimal recovery = 0.0;
            for (int i = 0; i < bid.Count; i++)
            {
                BigDecimal publicKey = bid[i];
                for (double j = 0; j < bid.Count; j++)
                {
                    if (i != j)
                    {
                        if (servers[i] == 1 || servers[(int) j] == 1) 
                        { 
                            double nominator = (j + 1);
                            double denominator = ((j + 1) - (i + 1));
                            double nomDenom = (nominator / denominator);
                            publicKey = publicKey.Multiply(nomDenom);
                        }
                    }
                }
                recovery = recovery.Add(publicKey);
            }
            MathContext mc = new MathContext(13);
            BigInteger recoveryCombined = recovery.Round(mc);
            recoveryCombined.Mod(modulus);

            while (recoveryCombined < 0)
            {
                recoveryCombined += modulus;
            }
            return recoveryCombined;
        }

        private void auctionShutdown()
        {
            p1text.BackColor = Color.Tomato;
            p1text.Text = "";
            p1text.Enabled = false;
            p1button.Visible = false;
            p2text.BackColor = Color.Tomato;
            p2text.Text = "";
            p2text.Enabled = false;
            p2button.Visible = false;
            p3text.BackColor = Color.Tomato;
            p3text.Text = "";
            p3text.Enabled = false;
            p3button.Visible = false;
            p4text.BackColor = Color.Tomato;
            p4text.Text = "";
            p4text.Enabled = false;
            p4button.Visible = false;
            p5text.BackColor = Color.Tomato;
            p5text.Text = "";
            p5text.Enabled = false;
            p5button.Visible = false;
            p6text.BackColor = Color.Tomato;
            p6text.Text = "";
            p6text.Enabled = false;
            p6button.Visible = false;
            p7text.BackColor = Color.Tomato;
            p7text.Text = "";
            p7text.Enabled = false;
            p7button.Visible = false;
            p8text.BackColor = Color.Tomato;
            p8text.Text = "";
            p8text.Enabled = false;
            p8button.Visible = false;
            s1button.Enabled = false;
            s2button.Enabled = false;
            s3button.Enabled = false;
            s4button.Enabled = false;
            atcombo.Enabled = false;
        }

        private void showWinner(string winner)
        {
            if (winner.Equals("Player 1")) { p1text.Visible = true; p1text.BackColor = Color.Chartreuse; p1text.Text = "WINNER"; p1text.TextAlign = HorizontalAlignment.Center; }
            if (winner.Equals("Player 2")) { p2text.Visible = true; p2text.BackColor = Color.Chartreuse; p2text.Text = "WINNER"; p2text.TextAlign = HorizontalAlignment.Center; }
            if (winner.Equals("Player 3")) { p3text.Visible = true; p3text.BackColor = Color.Chartreuse; p3text.Text = "WINNER"; p3text.TextAlign = HorizontalAlignment.Center; }
            if (winner.Equals("Player 4")) { p4text.Visible = true; p4text.BackColor = Color.Chartreuse; p4text.Text = "WINNER"; p4text.TextAlign = HorizontalAlignment.Center; }
            if (winner.Equals("Player 5")) { p5text.Visible = true; p5text.BackColor = Color.Chartreuse; p5text.Text = "WINNER"; p5text.TextAlign = HorizontalAlignment.Center; }
            if (winner.Equals("Player 6")) { p6text.Visible = true; p6text.BackColor = Color.Chartreuse; p6text.Text = "WINNER"; p6text.TextAlign = HorizontalAlignment.Center; }
            if (winner.Equals("Player 7")) { p7text.Visible = true; p7text.BackColor = Color.Chartreuse; p7text.Text = "WINNER"; p7text.TextAlign = HorizontalAlignment.Center; }
            if (winner.Equals("Player 8")) { p8text.Visible = true; p8text.BackColor = Color.Chartreuse; p8text.Text = "WINNER"; p8text.TextAlign = HorizontalAlignment.Center; }
            if (p1text.Visible == false) { p1text.Visible = true; p1text.BackColor = Color.Goldenrod; }
            if (p2text.Visible == false) { p2text.Visible = true; p2text.BackColor = Color.Goldenrod; }
            if (p3text.Visible == false) { p3text.Visible = true; p3text.BackColor = Color.Goldenrod; }
            if (p4text.Visible == false) { p4text.Visible = true; p4text.BackColor = Color.Goldenrod; }
            if (p5text.Visible == false) { p5text.Visible = true; p5text.BackColor = Color.Goldenrod; }
            if (p6text.Visible == false) { p6text.Visible = true; p6text.BackColor = Color.Goldenrod; }
            if (p7text.Visible == false) { p7text.Visible = true; p7text.BackColor = Color.Goldenrod; }
            if (p8text.Visible == false) { p8text.Visible = true; p8text.BackColor = Color.Goldenrod; }
        }
    }
}
