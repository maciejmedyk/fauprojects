﻿namespace COT6427
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.p1label = new System.Windows.Forms.Label();
            this.p2label = new System.Windows.Forms.Label();
            this.p3label = new System.Windows.Forms.Label();
            this.p4label = new System.Windows.Forms.Label();
            this.p5label = new System.Windows.Forms.Label();
            this.p6label = new System.Windows.Forms.Label();
            this.p7label = new System.Windows.Forms.Label();
            this.p8label = new System.Windows.Forms.Label();
            this.p1text = new System.Windows.Forms.TextBox();
            this.p1button = new System.Windows.Forms.Button();
            this.p2button = new System.Windows.Forms.Button();
            this.p2text = new System.Windows.Forms.TextBox();
            this.p3button = new System.Windows.Forms.Button();
            this.p3text = new System.Windows.Forms.TextBox();
            this.p4button = new System.Windows.Forms.Button();
            this.p4text = new System.Windows.Forms.TextBox();
            this.p5button = new System.Windows.Forms.Button();
            this.p5text = new System.Windows.Forms.TextBox();
            this.p6button = new System.Windows.Forms.Button();
            this.p6text = new System.Windows.Forms.TextBox();
            this.p7button = new System.Windows.Forms.Button();
            this.p7text = new System.Windows.Forms.TextBox();
            this.p8button = new System.Windows.Forms.Button();
            this.p8text = new System.Windows.Forms.TextBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.timelabel = new System.Windows.Forms.Label();
            this.s1picture = new System.Windows.Forms.PictureBox();
            this.p8picture = new System.Windows.Forms.PictureBox();
            this.p7picture = new System.Windows.Forms.PictureBox();
            this.p6picture = new System.Windows.Forms.PictureBox();
            this.p5picture = new System.Windows.Forms.PictureBox();
            this.p4picture = new System.Windows.Forms.PictureBox();
            this.p3picture = new System.Windows.Forms.PictureBox();
            this.p2picture = new System.Windows.Forms.PictureBox();
            this.p1picture = new System.Windows.Forms.PictureBox();
            this.s2picture = new System.Windows.Forms.PictureBox();
            this.s3picture = new System.Windows.Forms.PictureBox();
            this.s4picture = new System.Windows.Forms.PictureBox();
            this.s1text = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.s4button = new System.Windows.Forms.Button();
            this.s3button = new System.Windows.Forms.Button();
            this.s2button = new System.Windows.Forms.Button();
            this.s1button = new System.Windows.Forms.Button();
            this.s4label = new System.Windows.Forms.Label();
            this.s3label = new System.Windows.Forms.Label();
            this.s2label = new System.Windows.Forms.Label();
            this.s1label = new System.Windows.Forms.Label();
            this.s4text = new System.Windows.Forms.TextBox();
            this.s3text = new System.Windows.Forms.TextBox();
            this.s2text = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.atcombo = new System.Windows.Forms.ComboBox();
            this.modulolabel = new System.Windows.Forms.Label();
            this.a1label = new System.Windows.Forms.Label();
            this.a1picture = new System.Windows.Forms.PictureBox();
            this.finalizetext = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.s1picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p8picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p7picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p6picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p5picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p4picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s2picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s3picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s4picture)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.a1picture)).BeginInit();
            this.SuspendLayout();
            // 
            // p1label
            // 
            this.p1label.AutoSize = true;
            this.p1label.Location = new System.Drawing.Point(49, 9);
            this.p1label.Name = "p1label";
            this.p1label.Size = new System.Drawing.Size(45, 13);
            this.p1label.TabIndex = 8;
            this.p1label.Text = "Player 1";
            // 
            // p2label
            // 
            this.p2label.AutoSize = true;
            this.p2label.Location = new System.Drawing.Point(194, 9);
            this.p2label.Name = "p2label";
            this.p2label.Size = new System.Drawing.Size(45, 13);
            this.p2label.TabIndex = 9;
            this.p2label.Text = "Player 2";
            // 
            // p3label
            // 
            this.p3label.AutoSize = true;
            this.p3label.Location = new System.Drawing.Point(330, 9);
            this.p3label.Name = "p3label";
            this.p3label.Size = new System.Drawing.Size(45, 13);
            this.p3label.TabIndex = 10;
            this.p3label.Text = "Player 3";
            // 
            // p4label
            // 
            this.p4label.AutoSize = true;
            this.p4label.Location = new System.Drawing.Point(464, 9);
            this.p4label.Name = "p4label";
            this.p4label.Size = new System.Drawing.Size(45, 13);
            this.p4label.TabIndex = 11;
            this.p4label.Text = "Player 4";
            // 
            // p5label
            // 
            this.p5label.AutoSize = true;
            this.p5label.Location = new System.Drawing.Point(603, 9);
            this.p5label.Name = "p5label";
            this.p5label.Size = new System.Drawing.Size(45, 13);
            this.p5label.TabIndex = 12;
            this.p5label.Text = "Player 5";
            // 
            // p6label
            // 
            this.p6label.AutoSize = true;
            this.p6label.Location = new System.Drawing.Point(743, 9);
            this.p6label.Name = "p6label";
            this.p6label.Size = new System.Drawing.Size(45, 13);
            this.p6label.TabIndex = 13;
            this.p6label.Text = "Player 6";
            // 
            // p7label
            // 
            this.p7label.AutoSize = true;
            this.p7label.Location = new System.Drawing.Point(891, 9);
            this.p7label.Name = "p7label";
            this.p7label.Size = new System.Drawing.Size(45, 13);
            this.p7label.TabIndex = 14;
            this.p7label.Text = "Player 7";
            // 
            // p8label
            // 
            this.p8label.AutoSize = true;
            this.p8label.Location = new System.Drawing.Point(1030, 9);
            this.p8label.Name = "p8label";
            this.p8label.Size = new System.Drawing.Size(45, 13);
            this.p8label.TabIndex = 15;
            this.p8label.Text = "Player 8";
            // 
            // p1text
            // 
            this.p1text.Location = new System.Drawing.Point(27, 96);
            this.p1text.Name = "p1text";
            this.p1text.Size = new System.Drawing.Size(84, 20);
            this.p1text.TabIndex = 16;
            // 
            // p1button
            // 
            this.p1button.Location = new System.Drawing.Point(27, 122);
            this.p1button.Name = "p1button";
            this.p1button.Size = new System.Drawing.Size(84, 23);
            this.p1button.TabIndex = 17;
            this.p1button.Text = "Submit";
            this.p1button.UseVisualStyleBackColor = true;
            this.p1button.Click += new System.EventHandler(this.p1button_Click);
            // 
            // p2button
            // 
            this.p2button.Location = new System.Drawing.Point(175, 122);
            this.p2button.Name = "p2button";
            this.p2button.Size = new System.Drawing.Size(84, 23);
            this.p2button.TabIndex = 19;
            this.p2button.Text = "Submit";
            this.p2button.UseVisualStyleBackColor = true;
            this.p2button.Click += new System.EventHandler(this.p2button_Click);
            // 
            // p2text
            // 
            this.p2text.Location = new System.Drawing.Point(175, 96);
            this.p2text.Name = "p2text";
            this.p2text.Size = new System.Drawing.Size(84, 20);
            this.p2text.TabIndex = 18;
            // 
            // p3button
            // 
            this.p3button.Location = new System.Drawing.Point(310, 123);
            this.p3button.Name = "p3button";
            this.p3button.Size = new System.Drawing.Size(84, 23);
            this.p3button.TabIndex = 21;
            this.p3button.Text = "Submit";
            this.p3button.UseVisualStyleBackColor = true;
            this.p3button.Click += new System.EventHandler(this.p3button_Click);
            // 
            // p3text
            // 
            this.p3text.Location = new System.Drawing.Point(310, 96);
            this.p3text.Name = "p3text";
            this.p3text.Size = new System.Drawing.Size(84, 20);
            this.p3text.TabIndex = 20;
            // 
            // p4button
            // 
            this.p4button.Location = new System.Drawing.Point(443, 123);
            this.p4button.Name = "p4button";
            this.p4button.Size = new System.Drawing.Size(84, 23);
            this.p4button.TabIndex = 23;
            this.p4button.Text = "Submit";
            this.p4button.UseVisualStyleBackColor = true;
            this.p4button.Click += new System.EventHandler(this.p4button_Click);
            // 
            // p4text
            // 
            this.p4text.Location = new System.Drawing.Point(443, 96);
            this.p4text.Name = "p4text";
            this.p4text.Size = new System.Drawing.Size(84, 20);
            this.p4text.TabIndex = 22;
            // 
            // p5button
            // 
            this.p5button.Location = new System.Drawing.Point(582, 123);
            this.p5button.Name = "p5button";
            this.p5button.Size = new System.Drawing.Size(84, 23);
            this.p5button.TabIndex = 25;
            this.p5button.Text = "Submit";
            this.p5button.UseVisualStyleBackColor = true;
            this.p5button.Click += new System.EventHandler(this.p5button_Click);
            // 
            // p5text
            // 
            this.p5text.Location = new System.Drawing.Point(582, 96);
            this.p5text.Name = "p5text";
            this.p5text.Size = new System.Drawing.Size(84, 20);
            this.p5text.TabIndex = 24;
            // 
            // p6button
            // 
            this.p6button.Location = new System.Drawing.Point(723, 123);
            this.p6button.Name = "p6button";
            this.p6button.Size = new System.Drawing.Size(84, 23);
            this.p6button.TabIndex = 27;
            this.p6button.Text = "Submit";
            this.p6button.UseVisualStyleBackColor = true;
            this.p6button.Click += new System.EventHandler(this.p6button_Click);
            // 
            // p6text
            // 
            this.p6text.Location = new System.Drawing.Point(723, 96);
            this.p6text.Name = "p6text";
            this.p6text.Size = new System.Drawing.Size(84, 20);
            this.p6text.TabIndex = 26;
            // 
            // p7button
            // 
            this.p7button.Location = new System.Drawing.Point(869, 123);
            this.p7button.Name = "p7button";
            this.p7button.Size = new System.Drawing.Size(84, 23);
            this.p7button.TabIndex = 29;
            this.p7button.Text = "Submit";
            this.p7button.UseVisualStyleBackColor = true;
            this.p7button.Click += new System.EventHandler(this.p7button_Click);
            // 
            // p7text
            // 
            this.p7text.Location = new System.Drawing.Point(869, 96);
            this.p7text.Name = "p7text";
            this.p7text.Size = new System.Drawing.Size(84, 20);
            this.p7text.TabIndex = 28;
            // 
            // p8button
            // 
            this.p8button.Location = new System.Drawing.Point(1010, 123);
            this.p8button.Name = "p8button";
            this.p8button.Size = new System.Drawing.Size(84, 23);
            this.p8button.TabIndex = 31;
            this.p8button.Text = "Submit";
            this.p8button.UseVisualStyleBackColor = true;
            this.p8button.Click += new System.EventHandler(this.p8button_Click);
            // 
            // p8text
            // 
            this.p8text.Location = new System.Drawing.Point(1010, 96);
            this.p8text.Name = "p8text";
            this.p8text.Size = new System.Drawing.Size(84, 20);
            this.p8text.TabIndex = 30;
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // timelabel
            // 
            this.timelabel.AutoSize = true;
            this.timelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timelabel.Location = new System.Drawing.Point(10, 10);
            this.timelabel.Name = "timelabel";
            this.timelabel.Size = new System.Drawing.Size(184, 20);
            this.timelabel.TabIndex = 32;
            this.timelabel.Text = "Seconds Remaining : ";
            // 
            // s1picture
            // 
            this.s1picture.Image = global::COT6427_PROJECT.Properties.Resources.fileserver_server_icon__17_1_;
            this.s1picture.Location = new System.Drawing.Point(126, 18);
            this.s1picture.Name = "s1picture";
            this.s1picture.Size = new System.Drawing.Size(113, 88);
            this.s1picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.s1picture.TabIndex = 33;
            this.s1picture.TabStop = false;
            // 
            // p8picture
            // 
            this.p8picture.Image = global::COT6427_PROJECT.Properties.Resources._5024_200_1_;
            this.p8picture.Location = new System.Drawing.Point(1010, 25);
            this.p8picture.Name = "p8picture";
            this.p8picture.Size = new System.Drawing.Size(84, 75);
            this.p8picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p8picture.TabIndex = 7;
            this.p8picture.TabStop = false;
            // 
            // p7picture
            // 
            this.p7picture.Image = global::COT6427_PROJECT.Properties.Resources._5024_200_1_;
            this.p7picture.Location = new System.Drawing.Point(869, 25);
            this.p7picture.Name = "p7picture";
            this.p7picture.Size = new System.Drawing.Size(84, 75);
            this.p7picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p7picture.TabIndex = 6;
            this.p7picture.TabStop = false;
            // 
            // p6picture
            // 
            this.p6picture.Image = global::COT6427_PROJECT.Properties.Resources._5024_200_1_;
            this.p6picture.Location = new System.Drawing.Point(723, 25);
            this.p6picture.Name = "p6picture";
            this.p6picture.Size = new System.Drawing.Size(84, 75);
            this.p6picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p6picture.TabIndex = 5;
            this.p6picture.TabStop = false;
            // 
            // p5picture
            // 
            this.p5picture.Image = global::COT6427_PROJECT.Properties.Resources._5024_200_1_;
            this.p5picture.Location = new System.Drawing.Point(582, 25);
            this.p5picture.Name = "p5picture";
            this.p5picture.Size = new System.Drawing.Size(84, 75);
            this.p5picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p5picture.TabIndex = 4;
            this.p5picture.TabStop = false;
            // 
            // p4picture
            // 
            this.p4picture.Image = global::COT6427_PROJECT.Properties.Resources._5024_200_1_;
            this.p4picture.Location = new System.Drawing.Point(443, 25);
            this.p4picture.Name = "p4picture";
            this.p4picture.Size = new System.Drawing.Size(84, 75);
            this.p4picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p4picture.TabIndex = 3;
            this.p4picture.TabStop = false;
            // 
            // p3picture
            // 
            this.p3picture.Image = global::COT6427_PROJECT.Properties.Resources._5024_200_1_;
            this.p3picture.Location = new System.Drawing.Point(310, 25);
            this.p3picture.Name = "p3picture";
            this.p3picture.Size = new System.Drawing.Size(84, 75);
            this.p3picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p3picture.TabIndex = 2;
            this.p3picture.TabStop = false;
            // 
            // p2picture
            // 
            this.p2picture.Image = global::COT6427_PROJECT.Properties.Resources._5024_200_1_;
            this.p2picture.Location = new System.Drawing.Point(175, 25);
            this.p2picture.Name = "p2picture";
            this.p2picture.Size = new System.Drawing.Size(84, 75);
            this.p2picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p2picture.TabIndex = 1;
            this.p2picture.TabStop = false;
            // 
            // p1picture
            // 
            this.p1picture.Image = global::COT6427_PROJECT.Properties.Resources._5024_200_1_;
            this.p1picture.Location = new System.Drawing.Point(27, 25);
            this.p1picture.Name = "p1picture";
            this.p1picture.Size = new System.Drawing.Size(84, 75);
            this.p1picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p1picture.TabIndex = 0;
            this.p1picture.TabStop = false;
            // 
            // s2picture
            // 
            this.s2picture.Image = global::COT6427_PROJECT.Properties.Resources.fileserver_server_icon__17_1_;
            this.s2picture.Location = new System.Drawing.Point(384, 18);
            this.s2picture.Name = "s2picture";
            this.s2picture.Size = new System.Drawing.Size(113, 88);
            this.s2picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.s2picture.TabIndex = 34;
            this.s2picture.TabStop = false;
            // 
            // s3picture
            // 
            this.s3picture.Image = global::COT6427_PROJECT.Properties.Resources.fileserver_server_icon__17_1_;
            this.s3picture.Location = new System.Drawing.Point(635, 18);
            this.s3picture.Name = "s3picture";
            this.s3picture.Size = new System.Drawing.Size(113, 88);
            this.s3picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.s3picture.TabIndex = 35;
            this.s3picture.TabStop = false;
            // 
            // s4picture
            // 
            this.s4picture.Image = global::COT6427_PROJECT.Properties.Resources.fileserver_server_icon__17_1_;
            this.s4picture.Location = new System.Drawing.Point(894, 18);
            this.s4picture.Name = "s4picture";
            this.s4picture.Size = new System.Drawing.Size(113, 88);
            this.s4picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.s4picture.TabIndex = 36;
            this.s4picture.TabStop = false;
            // 
            // s1text
            // 
            this.s1text.AcceptsReturn = true;
            this.s1text.Enabled = false;
            this.s1text.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s1text.Location = new System.Drawing.Point(65, 135);
            this.s1text.Multiline = true;
            this.s1text.Name = "s1text";
            this.s1text.ReadOnly = true;
            this.s1text.Size = new System.Drawing.Size(229, 138);
            this.s1text.TabIndex = 37;
            this.s1text.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.s4button);
            this.panel1.Controls.Add(this.s3button);
            this.panel1.Controls.Add(this.s2button);
            this.panel1.Controls.Add(this.s1button);
            this.panel1.Controls.Add(this.s4label);
            this.panel1.Controls.Add(this.s3label);
            this.panel1.Controls.Add(this.s2label);
            this.panel1.Controls.Add(this.s1label);
            this.panel1.Controls.Add(this.s4text);
            this.panel1.Controls.Add(this.s3text);
            this.panel1.Controls.Add(this.s2text);
            this.panel1.Controls.Add(this.s1text);
            this.panel1.Controls.Add(this.s4picture);
            this.panel1.Controls.Add(this.s3picture);
            this.panel1.Controls.Add(this.s2picture);
            this.panel1.Controls.Add(this.s1picture);
            this.panel1.Location = new System.Drawing.Point(12, 251);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1123, 292);
            this.panel1.TabIndex = 38;
            // 
            // s4button
            // 
            this.s4button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.s4button.Location = new System.Drawing.Point(894, 106);
            this.s4button.Name = "s4button";
            this.s4button.Size = new System.Drawing.Size(113, 23);
            this.s4button.TabIndex = 47;
            this.s4button.TabStop = false;
            this.s4button.Text = "ONLINE";
            this.s4button.UseVisualStyleBackColor = true;
            this.s4button.Click += new System.EventHandler(this.s4button_Click);
            // 
            // s3button
            // 
            this.s3button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.s3button.Location = new System.Drawing.Point(635, 106);
            this.s3button.Name = "s3button";
            this.s3button.Size = new System.Drawing.Size(113, 23);
            this.s3button.TabIndex = 46;
            this.s3button.TabStop = false;
            this.s3button.Text = "ONLINE";
            this.s3button.UseVisualStyleBackColor = true;
            this.s3button.Click += new System.EventHandler(this.s3button_Click);
            // 
            // s2button
            // 
            this.s2button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.s2button.Location = new System.Drawing.Point(384, 107);
            this.s2button.Name = "s2button";
            this.s2button.Size = new System.Drawing.Size(113, 23);
            this.s2button.TabIndex = 45;
            this.s2button.TabStop = false;
            this.s2button.Text = "ONLINE";
            this.s2button.UseVisualStyleBackColor = true;
            this.s2button.Click += new System.EventHandler(this.s2button_Click);
            // 
            // s1button
            // 
            this.s1button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.s1button.Location = new System.Drawing.Point(126, 106);
            this.s1button.Name = "s1button";
            this.s1button.Size = new System.Drawing.Size(113, 23);
            this.s1button.TabIndex = 44;
            this.s1button.TabStop = false;
            this.s1button.Text = "ONLINE";
            this.s1button.UseVisualStyleBackColor = true;
            this.s1button.Click += new System.EventHandler(this.s1button_Click);
            // 
            // s4label
            // 
            this.s4label.AutoSize = true;
            this.s4label.Location = new System.Drawing.Point(929, 2);
            this.s4label.Name = "s4label";
            this.s4label.Size = new System.Drawing.Size(47, 13);
            this.s4label.TabIndex = 43;
            this.s4label.Text = "Server 4";
            // 
            // s3label
            // 
            this.s3label.AutoSize = true;
            this.s3label.Location = new System.Drawing.Point(665, 2);
            this.s3label.Name = "s3label";
            this.s3label.Size = new System.Drawing.Size(47, 13);
            this.s3label.TabIndex = 42;
            this.s3label.Text = "Server 3";
            // 
            // s2label
            // 
            this.s2label.AutoSize = true;
            this.s2label.Location = new System.Drawing.Point(419, 2);
            this.s2label.Name = "s2label";
            this.s2label.Size = new System.Drawing.Size(47, 13);
            this.s2label.TabIndex = 41;
            this.s2label.Text = "Server 2";
            // 
            // s1label
            // 
            this.s1label.AutoSize = true;
            this.s1label.Location = new System.Drawing.Point(159, 2);
            this.s1label.Name = "s1label";
            this.s1label.Size = new System.Drawing.Size(47, 13);
            this.s1label.TabIndex = 40;
            this.s1label.Text = "Server 1";
            // 
            // s4text
            // 
            this.s4text.AcceptsReturn = true;
            this.s4text.Enabled = false;
            this.s4text.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s4text.Location = new System.Drawing.Point(836, 134);
            this.s4text.Multiline = true;
            this.s4text.Name = "s4text";
            this.s4text.ReadOnly = true;
            this.s4text.Size = new System.Drawing.Size(229, 139);
            this.s4text.TabIndex = 40;
            this.s4text.TabStop = false;
            // 
            // s3text
            // 
            this.s3text.AcceptsReturn = true;
            this.s3text.Enabled = false;
            this.s3text.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s3text.Location = new System.Drawing.Point(578, 136);
            this.s3text.Multiline = true;
            this.s3text.Name = "s3text";
            this.s3text.ReadOnly = true;
            this.s3text.Size = new System.Drawing.Size(229, 139);
            this.s3text.TabIndex = 39;
            this.s3text.TabStop = false;
            // 
            // s2text
            // 
            this.s2text.AcceptsReturn = true;
            this.s2text.Enabled = false;
            this.s2text.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s2text.Location = new System.Drawing.Point(321, 136);
            this.s2text.Multiline = true;
            this.s2text.Name = "s2text";
            this.s2text.ReadOnly = true;
            this.s2text.Size = new System.Drawing.Size(229, 138);
            this.s2text.TabIndex = 38;
            this.s2text.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.p8button);
            this.panel2.Controls.Add(this.p8text);
            this.panel2.Controls.Add(this.p7button);
            this.panel2.Controls.Add(this.p7text);
            this.panel2.Controls.Add(this.p6button);
            this.panel2.Controls.Add(this.p6text);
            this.panel2.Controls.Add(this.p5button);
            this.panel2.Controls.Add(this.p5text);
            this.panel2.Controls.Add(this.p4button);
            this.panel2.Controls.Add(this.p4text);
            this.panel2.Controls.Add(this.p3button);
            this.panel2.Controls.Add(this.p3text);
            this.panel2.Controls.Add(this.p2button);
            this.panel2.Controls.Add(this.p2text);
            this.panel2.Controls.Add(this.p1button);
            this.panel2.Controls.Add(this.p1text);
            this.panel2.Controls.Add(this.p8label);
            this.panel2.Controls.Add(this.p7label);
            this.panel2.Controls.Add(this.p6label);
            this.panel2.Controls.Add(this.p5label);
            this.panel2.Controls.Add(this.p4label);
            this.panel2.Controls.Add(this.p3label);
            this.panel2.Controls.Add(this.p2label);
            this.panel2.Controls.Add(this.p1label);
            this.panel2.Controls.Add(this.p8picture);
            this.panel2.Controls.Add(this.p7picture);
            this.panel2.Controls.Add(this.p6picture);
            this.panel2.Controls.Add(this.p5picture);
            this.panel2.Controls.Add(this.p4picture);
            this.panel2.Controls.Add(this.p3picture);
            this.panel2.Controls.Add(this.p2picture);
            this.panel2.Controls.Add(this.p1picture);
            this.panel2.Location = new System.Drawing.Point(12, 549);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1123, 161);
            this.panel2.TabIndex = 39;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.a1label);
            this.panel3.Controls.Add(this.a1picture);
            this.panel3.Controls.Add(this.finalizetext);
            this.panel3.Location = new System.Drawing.Point(12, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1122, 233);
            this.panel3.TabIndex = 40;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.atcombo);
            this.panel4.Controls.Add(this.modulolabel);
            this.panel4.Controls.Add(this.timelabel);
            this.panel4.Location = new System.Drawing.Point(-1, -1);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1123, 44);
            this.panel4.TabIndex = 47;
            // 
            // atcombo
            // 
            this.atcombo.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.atcombo.BackColor = System.Drawing.SystemColors.Menu;
            this.atcombo.Cursor = System.Windows.Forms.Cursors.Default;
            this.atcombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atcombo.FormattingEnabled = true;
            this.atcombo.ItemHeight = 20;
            this.atcombo.Location = new System.Drawing.Point(256, 11);
            this.atcombo.MaxDropDownItems = 3;
            this.atcombo.Name = "atcombo";
            this.atcombo.Size = new System.Drawing.Size(352, 28);
            this.atcombo.TabIndex = 46;
            this.atcombo.TabStop = false;
            // 
            // modulolabel
            // 
            this.modulolabel.AutoSize = true;
            this.modulolabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modulolabel.Location = new System.Drawing.Point(631, 14);
            this.modulolabel.Name = "modulolabel";
            this.modulolabel.Size = new System.Drawing.Size(486, 20);
            this.modulolabel.TabIndex = 33;
            this.modulolabel.Text = "Modulus :  000000000000000000000000000000000000000";
            // 
            // a1label
            // 
            this.a1label.AutoSize = true;
            this.a1label.Location = new System.Drawing.Point(28, 75);
            this.a1label.Name = "a1label";
            this.a1label.Size = new System.Drawing.Size(66, 13);
            this.a1label.TabIndex = 45;
            this.a1label.Text = "Computation";
            // 
            // a1picture
            // 
            this.a1picture.Image = global::COT6427_PROJECT.Properties.Resources.fileserver_server_icon__17_1_;
            this.a1picture.Location = new System.Drawing.Point(3, 91);
            this.a1picture.Name = "a1picture";
            this.a1picture.Size = new System.Drawing.Size(113, 88);
            this.a1picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.a1picture.TabIndex = 44;
            this.a1picture.TabStop = false;
            // 
            // finalizetext
            // 
            this.finalizetext.Enabled = false;
            this.finalizetext.Location = new System.Drawing.Point(137, 57);
            this.finalizetext.Multiline = true;
            this.finalizetext.Name = "finalizetext";
            this.finalizetext.ReadOnly = true;
            this.finalizetext.Size = new System.Drawing.Size(957, 158);
            this.finalizetext.TabIndex = 34;
            this.finalizetext.TabStop = false;
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(1153, 717);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "MainForm";
            this.Text = "Maciej Medyk | COT6427 Secret Sharing Protocols | Sealed Bid Auction Simulation";
            ((System.ComponentModel.ISupportInitialize)(this.s1picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p8picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p7picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p6picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p5picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p4picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s2picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s3picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s4picture)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.a1picture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox p1picture;
        private System.Windows.Forms.PictureBox p2picture;
        private System.Windows.Forms.PictureBox p3picture;
        private System.Windows.Forms.PictureBox p4picture;
        private System.Windows.Forms.PictureBox p5picture;
        private System.Windows.Forms.PictureBox p6picture;
        private System.Windows.Forms.PictureBox p7picture;
        private System.Windows.Forms.PictureBox p8picture;
        private System.Windows.Forms.Label p1label;
        private System.Windows.Forms.Label p2label;
        private System.Windows.Forms.Label p3label;
        private System.Windows.Forms.Label p4label;
        private System.Windows.Forms.Label p5label;
        private System.Windows.Forms.Label p6label;
        private System.Windows.Forms.Label p7label;
        private System.Windows.Forms.Label p8label;
        private System.Windows.Forms.TextBox p1text;
        private System.Windows.Forms.Button p1button;
        private System.Windows.Forms.Button p2button;
        private System.Windows.Forms.TextBox p2text;
        private System.Windows.Forms.Button p3button;
        private System.Windows.Forms.TextBox p3text;
        private System.Windows.Forms.Button p4button;
        private System.Windows.Forms.TextBox p4text;
        private System.Windows.Forms.Button p5button;
        private System.Windows.Forms.TextBox p5text;
        private System.Windows.Forms.Button p6button;
        private System.Windows.Forms.TextBox p6text;
        private System.Windows.Forms.Button p7button;
        private System.Windows.Forms.TextBox p7text;
        private System.Windows.Forms.Button p8button;
        private System.Windows.Forms.TextBox p8text;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Label timelabel;
        private System.Windows.Forms.PictureBox s1picture;
        private System.Windows.Forms.PictureBox s2picture;
        private System.Windows.Forms.PictureBox s3picture;
        private System.Windows.Forms.PictureBox s4picture;
        private System.Windows.Forms.TextBox s1text;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox s4text;
        private System.Windows.Forms.TextBox s3text;
        private System.Windows.Forms.TextBox s2text;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label s1label;
        private System.Windows.Forms.Label s4label;
        private System.Windows.Forms.Label s3label;
        private System.Windows.Forms.Label s2label;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label modulolabel;
        private System.Windows.Forms.Label a1label;
        private System.Windows.Forms.PictureBox a1picture;
        private System.Windows.Forms.TextBox finalizetext;
        private System.Windows.Forms.Button s4button;
        private System.Windows.Forms.Button s3button;
        private System.Windows.Forms.Button s2button;
        private System.Windows.Forms.Button s1button;
        private System.Windows.Forms.ComboBox atcombo;
        private System.Windows.Forms.Panel panel4;
    }
}

