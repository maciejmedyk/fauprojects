import nltk, string
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

readfiles = ["webkb-test-stemmed.txt", "webkb-train-stemmed.txt"]
writefiles = ["webkb-test-stemmed-converted.txt", "webkb-train-stemmed-converted.txt"]
documents = []
documentsreorganized = []
dictionary = {}

def tokenize(text):
    stop_words = set(stopwords.words("english"))
    exclude = set(string.punctuation)
    stemmer = PorterStemmer()
    text = ''.join(ch for ch in text if ch not in exclude)
    document = nltk.word_tokenize(text)
    document_filtered = []
    for word in document:
        if word not in stop_words:
            document_filtered.append(word.lower())
    return [stemmer.stem(item) for item in document_filtered]

def reconcile(documents):
    for i in range(0, len(documents)):
        document = []
        for j in range(0, len(documents[i])):
            string = ""
            strings = {}
            for k in range(0, len(documents[i][j])):
                if(k == 0):
                    keyword = documents[i][j][k]
                    if(keyword[0] == "f"):
                        string += "1 "
                    elif(keyword[0] == "c"):
                        string += "2 "
                    elif(keyword[0] == "s"):
                        string += "3 "
                    elif(keyword[0] == "p"):
                        string += "4 "
                else:
                    if dictionary[documents[i][j][k]] in strings.keys():
                        count = strings[dictionary[documents[i][j][k]]]
                        strings[dictionary[documents[i][j][k]]] = count + 1
                    else:
                        strings[dictionary[documents[i][j][k]]] = 1
            maximum = 0
            for key in strings:
                if key > maximum:
                    maximum = key;
            for k in range(0, maximum):
                if k in strings:
                    string += str(k) + ":" + str(strings[k]) + " "
            string = string[:-1]
            if len(string) > 3:
                document.append(string)
        documentsreorganized.append(document)

def createdictonary():
    tracker = 10
    for i in range(0, len(documents)):
        for j in range(0, len(documents[i])):
            for k in range(0, len(documents[i][j])):
                if documents[i][j][k] in dictionary.keys():
                    continue
                else:
                    dictionary[documents[i][j][k]] = tracker
                    tracker += 1

def loadfile(readfiles):
    for i in range(0, len(readfiles)):
        with open("files\\" + str(readfiles[i]), "r") as file:
            document = file.read().split("\n")
        context = []
        for i in range(0, len(document)):
            sentence = tokenize(document[i])
            context.append(sentence)
        documents.append(context)

def readfile(path):
    with open(path, "r") as file:
        document = file.read().split("\n")
    return document

def writefile():
    for i in range(0, len(writefiles)):
        with open("files\\" + str(writefiles[i]), "w") as file:
            for j in range(0, len(documentsreorganized[i])):
                file.write(documentsreorganized[i][j] + "\n")

print("Reading Files")
loadfile(readfiles)
print("Creating Dictionary")
createdictonary()
print("Reconciling Files With Dictionary")
reconcile(documents)
print("Writing Files")
writefile()