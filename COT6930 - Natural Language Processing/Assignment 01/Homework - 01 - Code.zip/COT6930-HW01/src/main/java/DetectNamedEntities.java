import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.namefind.TokenNameFinderModel;
import opennlp.tools.util.Span;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class DetectNamedEntities {

    public Span[] detectPersons(String[] context) throws Exception {
        ClassLoader classLoader = getClass().getClassLoader();
        InputStream inputStream = new FileInputStream(new File(classLoader.getResource("en-ner-person.bin").getFile()));
        TokenNameFinderModel model = new TokenNameFinderModel(inputStream);
        NameFinderME finder = new NameFinderME(model);
        return finder.find(context);
    }

    public Span[] detectLocations(String[] context) throws Exception {
        ClassLoader classLoader = getClass().getClassLoader();
        InputStream inputStream = new FileInputStream(new File(classLoader.getResource("en-ner-location.bin").getFile()));
        TokenNameFinderModel model = new TokenNameFinderModel(inputStream);
        NameFinderME finder = new NameFinderME(model);
        return finder.find(context);
    }
}