import opennlp.tools.util.Span;

public class HW01 {

    public static void main(String[] args) throws Exception {

        Printer print = new Printer();
        String context = new FileLoader().readFile("newsArticle.txt");

        DetectSentences detectSentences = new DetectSentences();
        String[] sentences = detectSentences.detect(context);
        System.out.println("Array Containing Separate Sentences\n" + print.printSentences(sentences) + "\n");

        for(int index = 0; index < sentences.length; index++){
            DetectTokenizableWords tokenizedWords = new DetectTokenizableWords();
            String[] tokenizedSentence = tokenizedWords.tokenize(sentences[index]);

            DetectPartOfSpeech partOfSpeech = new DetectPartOfSpeech();
            String[] partOfSpeechText = partOfSpeech.partOfSpeech(tokenizedSentence);

            DetectNamedEntities detectNamedEntities = new DetectNamedEntities();
            Span[] persons = detectNamedEntities.detectPersons(tokenizedSentence);
            Span[] locations = detectNamedEntities.detectLocations(tokenizedSentence);

            System.out.println("Array of Tokenized Words for Sentence " +  (index + 1) + "\n" + print.printWords(tokenizedSentence, partOfSpeechText) + "\n");
            if(persons.length > 0 || locations.length > 0){
                if(persons.length > 0) {
                    System.out.println(print.printSpan(persons, tokenizedSentence));
                }
                if(locations.length > 0) {
                    System.out.println(print.printSpan(locations,tokenizedSentence));
                }
                System.out.print("\n");
            }
        }
    }
}