import opennlp.tools.sentdetect.SentenceDetector;
import opennlp.tools.sentdetect.SentenceDetectorME;
import opennlp.tools.sentdetect.SentenceModel;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class DetectSentences  {

    public String[] detect(String fileContext) throws Exception {

        ClassLoader classLoader = getClass().getClassLoader();
        InputStream inputStream = new FileInputStream(new File(classLoader.getResource("en-sent.bin").getFile()));
        SentenceModel model = new SentenceModel(inputStream);
        SentenceDetector detector = new SentenceDetectorME(model);
        return detector.sentDetect(fileContext);
    }
}