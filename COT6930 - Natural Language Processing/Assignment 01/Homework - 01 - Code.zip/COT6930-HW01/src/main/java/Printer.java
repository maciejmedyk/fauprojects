import opennlp.tools.util.Span;

public class Printer {

    public String printSentences(String[] context) {
        String result = "";
        for (int index = 0; index < context.length; index++) {
            result += "[ " + context[index] + " ] , \n";
        }
        result = result.substring(0, result.length() - 3);
        return result;
    }

    public String printWords(String[] contextTokens, String[] contextPOS) {
        String result = "";
        for (int index = 0; index < contextTokens.length; index++) {
            result += "[[ " + contextTokens[index] + " ],";
            result += "[ " + contextPOS[index] + " ]] , ";
            if(index % 10 == 9) {
                result += "\n";
            }
        }
        result = result.substring(0, result.length() - 3);
        return result;
    }

    public String printSpan(Span[] span, String[] context) {
        String result = "";
        result += span[0].getType().toUpperCase() + " : ";
        for(int index = 0; index < span.length; index++){
            int start = span[index].getStart();
            int end = span[index].getEnd();
            for(int spanIndex = start; spanIndex < end; spanIndex++){
                result += "[ " + context[spanIndex] + " ]";
            }
        }
        return result;
    }
}