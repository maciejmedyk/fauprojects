import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class DetectPartOfSpeech {

    public String[] partOfSpeech(String[] context) throws Exception {
        ClassLoader classLoader = getClass().getClassLoader();
        InputStream inputStream = new FileInputStream(new File(classLoader.getResource("en-pos-maxent.bin").getFile()));
        POSModel model = new POSModel(inputStream);
        POSTaggerME tagger = new POSTaggerME(model);
        return tagger.tag(context);
    }
}