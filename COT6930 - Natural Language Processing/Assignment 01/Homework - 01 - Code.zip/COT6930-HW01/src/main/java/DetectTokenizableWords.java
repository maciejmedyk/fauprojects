import opennlp.tools.tokenize.SimpleTokenizer;

public class DetectTokenizableWords {

    public String[] tokenize(String fileContext) {
        SimpleTokenizer simpleTokenizer = SimpleTokenizer.INSTANCE;
        return simpleTokenizer.tokenize(fileContext);
    }
}